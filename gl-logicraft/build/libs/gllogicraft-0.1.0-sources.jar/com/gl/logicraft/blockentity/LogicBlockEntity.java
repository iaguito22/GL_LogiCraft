package com.gl.logicraft.blockentity;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

/**
 * Placeholder block entity class for storing logic state and configurations.
 * This class will hold the programmed logic, current input/output states,
 * and handle synchronization between server and client for the GUI.
 */
public class LogicBlockEntity extends class_2586 {

    public LogicBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    // TODO: Implement readNbt and writeNbt to persist programmed logic
    // TODO: Implement LogicComponent storage and execution (from circuit package)
}
