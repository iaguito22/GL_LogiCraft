package com.gl.logicraft.blockentity;

import com.gl.logicraft.circuit.CircuitState;
import com.gl.logicraft.circuit.GuiComponent;
import com.gl.logicraft.circuit.LogicComponent;
import com.gl.logicraft.circuit.SignalPropagator;
import com.gl.logicraft.circuit.Wire;
import com.gl.logicraft.registry.ModBlockEntities;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/**
 * Block entity for the LogicChipBlock.
 *
 * Stores the circuit editor layout (GuiComponent + Wire lists) and evaluates
 * the circuit graph when inputs change. Results are written to CircuitState.outputs.
 */
public class LogicChipBlockEntity extends class_2586 {

    public static final int MAX_COMPONENTS = 8;

    // Fixed node IDs --------------------------------------------------------
    public static final String NODE_REDST_IN  = "REDST_IN";
    public static final String NODE_REDST_OUT = "REDST_OUT";
    public static final String NODE_IN(int n) { return "IN_" + n; }  // helper – not valid Java, see below

    // -----------------------------------------------------------------------
    // State
    // -----------------------------------------------------------------------

    private final CircuitState circuitState = new CircuitState();

    /** Visual layout — persisted and synced to player GUI. */
    private final List<GuiComponent> guiComponents = new ArrayList<>();
    private final List<Wire>         wires         = new ArrayList<>();

    /** Legacy execution-side list (kept for SignalPropagator compat). */
    private final List<LogicComponent> components = new ArrayList<>();

    boolean isPropagating = false;

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    public LogicChipBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.LOGIC_CHIP_BLOCK_ENTITY, pos, state);
    }

    // -----------------------------------------------------------------------
    // Accessors
    // -----------------------------------------------------------------------

    public CircuitState          getCircuitState()    { return circuitState; }
    public List<GuiComponent>    getGuiComponents()   { return guiComponents; }
    public List<Wire>            getWires()           { return wires; }
    public List<LogicComponent>  getLogicComponents() { return components; }

    // -----------------------------------------------------------------------
    // Graph evaluation
    // -----------------------------------------------------------------------

    /**
     * Evaluates the circuit by tracing the wire graph.
     * Input node signals → gate evaluations → output node signals.
     * If any circuit output changed, propagates to the world and neighbours.
     */
    public void evaluate() {
        if (field_11863 == null) return;

        boolean[] outputsBefore = Arrays.copyOf(circuitState.outputs, CircuitState.SIGNAL_COUNT);

        // ------ Build signal map ------
        Map<String, boolean[]> sigs = new HashMap<>();

        // Fixed input nodes
        sigs.put(NODE_REDST_IN, new boolean[]{circuitState.inputs[0]});
        for (int i = 0; i < 4; i++) {
            sigs.put("IN_" + i, new boolean[]{circuitState.inputs[i + 1]});
        }

        // Settle signals with up to (size+1) passes (handles any topological order)
        int passes = guiComponents.size() + 1;
        for (int p = 0; p < passes; p++) {
            for (GuiComponent gc : guiComponents) {
                int inCount = gc.getInputCount();
                boolean[] gateInputs = new boolean[inCount];
                for (Wire w : wires) {
                    if (w.toId.equals(gc.id) && w.toPort < inCount) {
                        boolean[] src = sigs.get(w.fromId);
                        if (src != null && w.fromPort < src.length) {
                            gateInputs[w.toPort] = src[w.fromPort];
                        }
                    }
                }
                boolean result = evalGate(gc.type, gateInputs);
                sigs.put(gc.id, new boolean[]{result});
            }
        }

        // Read output nodes
        circuitState.outputs[0] = getSignal(sigs, NODE_REDST_OUT);
        for (int i = 0; i < 4; i++) {
            circuitState.outputs[i + 1] = getSignal(sigs, "OUT_" + i);
        }

        // ------ Propagate if changed ------
        boolean changed = !Arrays.equals(outputsBefore, circuitState.outputs);
        if (changed) {
            field_11863.method_8408(field_11867, method_11010().method_26204());
            isPropagating = true;
            try {
                SignalPropagator.propagate(field_11863, field_11867, circuitState.outputs);
            } finally {
                isPropagating = false;
            }
            method_5431();
        }
    }

    private boolean evalGate(String type, boolean[] inputs) {
        return switch (type) {
            case "and"  -> { boolean r = true;  for (boolean b : inputs) r &= b; yield r; }
            case "or"   -> { boolean r = false; for (boolean b : inputs) r |= b; yield r; }
            case "not"  -> inputs.length > 0 && !inputs[0];
            default     -> inputs.length > 0 && inputs[0]; // pass
        };
    }

    private boolean getSignal(Map<String, boolean[]> sigs, String nodeId) {
        // Check if any wire delivers a signal to this output node
        for (Wire w : wires) {
            if (w.toId.equals(nodeId)) {
                boolean[] src = sigs.get(w.fromId);
                if (src != null && w.fromPort < src.length) {
                    return src[w.fromPort];
                }
            }
        }
        return false;
    }

    // -----------------------------------------------------------------------
    // Incoming neighbour signals
    // -----------------------------------------------------------------------

    public void receiveSignals(boolean[] signals) {
        if (isPropagating) return;
        boolean changed = false;
        int len = Math.min(signals.length, CircuitState.SIGNAL_COUNT);
        for (int i = 0; i < len; i++) {
            if (signals[i] && !circuitState.inputs[i]) {
                circuitState.inputs[i] = true;
                changed = true;
            }
        }
        if (changed) evaluate();
    }

    // -----------------------------------------------------------------------
    // GUI data serialization (used for screen open data packet)
    // -----------------------------------------------------------------------

    public class_2487 serializeGuiData() {
        class_2487 nbt = new class_2487();

        class_2499 gcList = new class_2499();
        for (GuiComponent gc : guiComponents) gcList.add(gc.toNbt());
        nbt.method_10566("GuiComponents", gcList);

        class_2499 wList = new class_2499();
        for (Wire w : wires) wList.add(w.toNbt());
        nbt.method_10566("Wires", wList);

        return nbt;
    }

    public void deserializeGuiData(class_2487 nbt) {
        guiComponents.clear();
        wires.clear();

        class_2499 gcList = nbt.method_10554("GuiComponents", class_2520.field_33260);
        for (int i = 0; i < gcList.size() && i < MAX_COMPONENTS; i++) {
            guiComponents.add(GuiComponent.fromNbt(gcList.method_10602(i)));
        }

        class_2499 wList = nbt.method_10554("Wires", class_2520.field_33260);
        for (int i = 0; i < wList.size(); i++) {
            wires.add(Wire.fromNbt(wList.method_10602(i)));
        }
    }

    // -----------------------------------------------------------------------
    // NBT persistence
    // -----------------------------------------------------------------------

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10566("CircuitState", circuitState.toNbt());
        nbt.method_10566("GuiData", serializeGuiData());
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        if (nbt.method_10545("CircuitState")) {
            circuitState.fromNbt(nbt.method_10562("CircuitState"));
        }
        if (nbt.method_10545("GuiData")) {
            deserializeGuiData(nbt.method_10562("GuiData"));
        }
    }
}
