package com.gl.logicraft.registry;

import com.gl.logicraft.GLLogiCraft;
import com.gl.logicraft.block.LogicChipBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Registry class for all blocks added by GL_LogiCraft.
 * Add new blocks here as static fields and register via registerBlock().
 */
public class ModBlocks {

    public static final class_5321<class_2248> LOGIC_CHIP_KEY = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GLLogiCraft.MOD_ID, "logic_chip"));

    /**
     * Logic Chip — a nearly-invisible attachment block.
     * Settings: no collision, non-opaque, does not block light.
     */
    public static final LogicChipBlock LOGIC_CHIP = class_2378.method_39197(
            class_7923.field_41175,
            LOGIC_CHIP_KEY,
            new LogicChipBlock(
                    class_4970.class_2251.method_9637()
                            .method_63500(LOGIC_CHIP_KEY)
                            .method_31710(class_3620.field_16008)
                            .method_9634()
                            .method_22488()
                            .method_36557(1.0f)
                            .method_36558(1.0f)
                            .method_50012(net.minecraft.class_3619.field_15971)
            )
    );

    // -----------------------------------------------------------------------

    public static void register() {
        GLLogiCraft.LOGGER.info("Registering GL_LogiCraft Blocks...");
        // Static fields are initialised when this class is first loaded;
        // calling register() ensures that happens at the right time.
    }

    private static class_2248 registerBlock(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(GLLogiCraft.MOD_ID, name), block);
    }
}
