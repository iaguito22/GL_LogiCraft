package com.gl.logicraft.registry;

import com.gl.logicraft.GLLogiCraft;
import com.gl.logicraft.gui.LogicScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import net.minecraft.class_9135;

/**
 * Registry class for GUI screen handlers.
 */
public class ModScreenHandlers {

    /**
     * Screen handler type for the circuit editor.
     * Uses ExtendedScreenHandlerType so the server can pass circuit data to the client.
     * NBT_COMPOUND codec is used to transmit the pos + circuit layout.
     */
    public static final class_3917<LogicScreenHandler> LOGIC_SCREEN =
            class_2378.method_10230(
                    class_7923.field_41187,
                    class_2960.method_60655(GLLogiCraft.MOD_ID, "logic_screen"),
                    new ExtendedScreenHandlerType<>(
                            (syncId, inv, data) -> new LogicScreenHandler(syncId, inv, data),
                            class_9135.field_48556
                    )
            );

    public static void register() {
        GLLogiCraft.LOGGER.info("Registering GL_LogiCraft Screen Handlers...");
    }
}
