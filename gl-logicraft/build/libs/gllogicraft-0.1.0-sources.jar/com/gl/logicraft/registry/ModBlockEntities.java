package com.gl.logicraft.registry;

import com.gl.logicraft.GLLogiCraft;
import com.gl.logicraft.blockentity.LogicChipBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Registry class for all block entities added by GL_LogiCraft.
 */
public class ModBlockEntities {

    /**
     * Block entity type for LogicChipBlock.
     * Must be registered AFTER ModBlocks (so LOGIC_CHIP is already initialised).
     */
    public static final class_2591<LogicChipBlockEntity> LOGIC_CHIP_BLOCK_ENTITY =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(GLLogiCraft.MOD_ID, "logic_chip"),
                    FabricBlockEntityTypeBuilder.create(LogicChipBlockEntity::new, ModBlocks.LOGIC_CHIP).build()
            );

    public static void register() {
        GLLogiCraft.LOGGER.info("Registering GL_LogiCraft Block Entities...");
    }
}
