package com.gl.logicraft.registry;

import com.gl.logicraft.GLLogiCraft;
import com.gl.logicraft.item.WrenchItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Registry class for all items added by GL_LogiCraft.
 */
public class ModItems {

    public static final class_5321<class_1792> LOGIC_CHIP_KEY = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GLLogiCraft.MOD_ID, "logic_chip"));
    public static final class_5321<class_1792> WRENCH_KEY = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GLLogiCraft.MOD_ID, "wrench"));

    /** Block item so the LogicChip can exist in inventory and be placed. */
    public static final class_1792 LOGIC_CHIP = class_2378.method_39197(
            class_7923.field_41178,
            LOGIC_CHIP_KEY,
            new class_1747(ModBlocks.LOGIC_CHIP, new class_1792.class_1793().method_63686(LOGIC_CHIP_KEY).method_63685())
    );

    /** The Logic Wrench — opens the circuit editor GUI and removes chips. */
    public static final class_1792 WRENCH = class_2378.method_39197(
            class_7923.field_41178,
            WRENCH_KEY,
            new WrenchItem(new class_1792.class_1793().method_63686(WRENCH_KEY).method_7889(1))
    );

    /** Creative tab for GL_LogiCraft items. */
    public static final class_1761 ITEM_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(GLLogiCraft.MOD_ID, "group"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.gllogicraft.group"))
                    .method_47320(() -> new net.minecraft.class_1799(WRENCH))
                    .method_47317((ctx, entries) -> {
                        entries.method_45421(LOGIC_CHIP);
                        entries.method_45421(WRENCH);
                    })
                    .method_47324()
    );

    public static void register() {
        GLLogiCraft.LOGGER.info("Registering GL_LogiCraft Items...");
        // Static initialiser triggers field assignment.
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(GLLogiCraft.MOD_ID, name), item);
    }
}
