package com.gl.logicraft.network;

import com.gl.logicraft.GLLogiCraft;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * C2S packet: sent when the player closes the circuit editor GUI.
 * Carries the BlockPos of the chip and the full serialized circuit (GuiComponents + Wires).
 */
public record SaveCircuitPayload(class_2338 pos, class_2487 circuit) implements class_8710 {

    public static final class_9154<SaveCircuitPayload> ID =
            new class_9154<>(class_2960.method_60655(GLLogiCraft.MOD_ID, "save_circuit"));

    public static final class_9139<class_9129, SaveCircuitPayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404,       SaveCircuitPayload::pos,
                    class_9135.field_48556,   SaveCircuitPayload::circuit,
                    SaveCircuitPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() { return ID; }
}
