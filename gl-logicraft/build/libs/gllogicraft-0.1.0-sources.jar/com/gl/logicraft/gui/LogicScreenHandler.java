package com.gl.logicraft.gui;

import com.gl.logicraft.blockentity.LogicChipBlockEntity;
import com.gl.logicraft.circuit.GuiComponent;
import com.gl.logicraft.circuit.Wire;
import com.gl.logicraft.network.SaveCircuitPayload;
import com.gl.logicraft.registry.ModScreenHandlers;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;

/**
 * Screen handler for the circuit editor GUI.
 *
 * Server constructor: uses BlockPos to locate the BlockEntity directly.
 * Client constructor: receives NbtCompound (from ExtendedScreenHandlerType) with pos + circuit.
 *
 * On GUI close (client): sends SaveCircuitPayload C2S to persist the circuit.
 * On server receive: deserializes into LogicChipBlockEntity and re-evaluates.
 */
public class LogicScreenHandler extends class_1703 {

    private final class_2338 chipPos;

    // Circuit data held client-side for rendering in LogicScreen
    private final List<GuiComponent> guiComponents = new ArrayList<>();
    private final List<Wire>         wires         = new ArrayList<>();
    public final boolean[]           startingInputs = new boolean[5];

    // -----------------------------------------------------------------------
    // Server-side constructor (called by WrenchItem.useOnBlock createMenu)
    // -----------------------------------------------------------------------
    public LogicScreenHandler(int syncId, class_1661 inv, class_2338 pos) {
        super(ModScreenHandlers.LOGIC_SCREEN, syncId);
        this.chipPos = pos;
    }

    // -----------------------------------------------------------------------
    // Client-side constructor (called by Fabric with ExtendedScreenHandlerType data)
    // -----------------------------------------------------------------------
    public LogicScreenHandler(int syncId, class_1661 inv, class_2487 data) {
        super(ModScreenHandlers.LOGIC_SCREEN, syncId);
        this.chipPos = new class_2338(
                data.method_10550("posX"),
                data.method_10550("posY"),
                data.method_10550("posZ")
        );
        if (data.method_10545("GuiData")) {
            class_2487 gui = data.method_10562("GuiData");

            class_2499 gcList = gui.method_10554("GuiComponents", class_2520.field_33260);
            for (int i = 0; i < gcList.size(); i++) {
                guiComponents.add(GuiComponent.fromNbt(gcList.method_10602(i)));
            }

            class_2499 wList = gui.method_10554("Wires", class_2520.field_33260);
            for (int i = 0; i < wList.size(); i++) {
                wires.add(Wire.fromNbt(wList.method_10602(i)));
            }
            if (gui.method_10545("CircuitInputs")) {
                byte[] ins = gui.method_10547("CircuitInputs");
                for (int i = 0; i < ins.length && i < startingInputs.length; i++) {
                    startingInputs[i] = (ins[i] != 0);
                }
            }
        }

    }

    // -----------------------------------------------------------------------
    // Accessors used by LogicScreen renderer
    // -----------------------------------------------------------------------

    public class_2338 getChipPos()             { return chipPos; }
    public List<GuiComponent> getGuiComponents() { return guiComponents; }
    public List<Wire>         getWires()         { return wires; }

    // -----------------------------------------------------------------------
    // Called from LogicScreen when player closes — sends data to server
    // -----------------------------------------------------------------------

    public void saveToServer() {
        class_2487 guiData = new class_2487();

        class_2499 gcList = new class_2499();
        for (GuiComponent gc : guiComponents) gcList.add(gc.toNbt());
        guiData.method_10566("GuiComponents", gcList);

        class_2499 wList = new class_2499();
        for (Wire w : wires) wList.add(w.toNbt());
        guiData.method_10566("Wires", wList);

        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
                .send(new SaveCircuitPayload(chipPos, guiData));
    }

    // -----------------------------------------------------------------------
    // Server-side: apply received circuit data to the block entity
    // -----------------------------------------------------------------------

    public static void handleSaveCircuit(SaveCircuitPayload payload, net.minecraft.class_3222 player) {
        if (!(player.method_37908() instanceof class_3218 sw)) return;
        if (!(sw.method_8321(payload.pos()) instanceof LogicChipBlockEntity chip)) return;

        chip.deserializeGuiData(payload.circuit());
        chip.evaluate();
    }

    // -----------------------------------------------------------------------
    // ScreenHandler boilerplate
    // -----------------------------------------------------------------------

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}
