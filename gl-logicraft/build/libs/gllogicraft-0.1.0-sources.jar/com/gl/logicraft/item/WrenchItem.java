package com.gl.logicraft.item;

import com.gl.logicraft.block.LogicChipBlock;
import com.gl.logicraft.blockentity.LogicChipBlockEntity;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import com.gl.logicraft.gui.LogicScreenHandler;
import com.gl.logicraft.registry.ModScreenHandlers;

/**
 * The Logic Wrench item.
 * - Right-click on a LogicChipBlock → opens the circuit editor GUI.
 * - Left-click (mining) → breaks the chip normally and drops it as an item.
 */
public class WrenchItem extends class_1792 {

    public WrenchItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_1657 player = context.method_8036();

        if (!(world.method_8320(pos).method_26204() instanceof LogicChipBlock)) {
            return class_1269.field_5811;
        }

        // Client side: return success to prevent ghost hand animation
        if (world.method_8608()) return class_1269.field_5812;

        // Server side: open the GUI if the block entity exists
        if (player instanceof class_3222 serverPlayer
                && world.method_8321(pos) instanceof LogicChipBlockEntity chip) {

            serverPlayer.method_17355(new ExtendedScreenHandlerFactory<class_2487>() {

                @Override
                public class_2487 getScreenOpeningData(class_3222 p) {
                    // Pack pos + circuit layout into a single NbtCompound
                    class_2487 data = new class_2487();
                    data.method_10569("posX", pos.method_10263());
                    data.method_10569("posY", pos.method_10264());
                    data.method_10569("posZ", pos.method_10260());
                    data.method_10566("GuiData", chip.serializeGuiData());
                    return data;
                }

                @Override
                public class_2561 method_5476() {
                    return class_2561.method_43471("container.gllogicraft.logic_chip");
                }

                @Override
                public class_1703 createMenu(int syncId, class_1661 inv, class_1657 p) {
                    // Server-side handler — constructed from BlockPos
                    return new LogicScreenHandler(syncId, inv, pos);
                }
            });
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }
}
