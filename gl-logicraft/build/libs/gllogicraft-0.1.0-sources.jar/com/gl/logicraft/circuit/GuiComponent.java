package com.gl.logicraft.circuit;

import net.minecraft.class_2487;

/**
 * Represents a visual component placed on the circuit editor grid.
 * This is the GUI-side data model (not the execution-side LogicComponent).
 * When the user saves, the GuiComponent+Wire graph is evaluated directly.
 */
public class GuiComponent {

    public final String id;   // unique ID used by Wire references
    public final String type; // "and", "or", "not", "pass"
    public int gridX, gridY;  // cell coordinates on the 30×30 grid

    public GuiComponent(String id, String type, int gridX, int gridY) {
        this.id = id;
        this.type = type;
        this.gridX = gridX;
        this.gridY = gridY;
    }

    /** How many input ports does this gate type have? */
    public static int inputCountFor(String type) {
        return switch (type) {
            case "and", "or" -> 2;
            default           -> 1; // not, pass
        };
    }

    public int getInputCount()  { return inputCountFor(type); }
    public int getOutputCount() { return 1; }

    /** Display label shown inside the grid cell. */
    public String getLabel() {
        return switch (type) {
            case "and"  -> "AND";
            case "or"   -> "OR";
            case "not"  -> "NOT";
            case "pass" -> "PASS";
            default     -> type.toUpperCase();
        };
    }

    // -----------------------------------------------------------------------
    // NBT
    // -----------------------------------------------------------------------

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582("id",   id);
        nbt.method_10582("type", type);
        nbt.method_10569("x", gridX);
        nbt.method_10569("y", gridY);
        return nbt;
    }

    public static GuiComponent fromNbt(class_2487 nbt) {
        return new GuiComponent(
            nbt.method_10558("id"),
            nbt.method_10558("type"),
            nbt.method_10550("x"),
            nbt.method_10550("y")
        );
    }
}
