package com.gl.logicraft.circuit;

import com.gl.logicraft.blockentity.LogicChipBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

/**
 * Handles cross-chip signal propagation.
 *
 * When a LogicChip's outputs change, this class checks all 6 neighbouring
 * block positions for other LogicChipBlockEntities and forwards the output
 * signals to them using OR-merge semantics (a true from ANY neighbour wins).
 *
 * Anti-loop protection is done via the isPropagating flag on each entity.
 */
public class SignalPropagator {

    private SignalPropagator() {}  // static utility class

    /**
     * Check all 6 neighbours of {@code pos}. If any of them contains a
     * {@link LogicChipBlockEntity}, call {@code receiveSignals(outputs)} on it.
     *
     * @param world   the server-side world
     * @param pos     position of the chip that just finished evaluating
     * @param outputs the chip's current output array (length == CircuitState.SIGNAL_COUNT)
     */
    public static void propagate(class_1937 world, class_2338 pos, boolean[] outputs) {
        if (world.method_8608()) return; // server-side only

        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbourPos = pos.method_10093(dir);
            if (world.method_8321(neighbourPos) instanceof LogicChipBlockEntity neighbour) {
                neighbour.receiveSignals(outputs);
            }
        }
    }
}
