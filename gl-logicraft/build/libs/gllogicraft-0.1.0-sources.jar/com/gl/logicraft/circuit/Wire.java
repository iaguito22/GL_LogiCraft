package com.gl.logicraft.circuit;

import net.minecraft.class_2487;

/**
 * A wire connects the output port of one component/node to the input port of another.
 *
 * Node IDs for the fixed edge nodes:
 *   Inputs  (left edge): "REDST_IN", "IN_0" … "IN_3"
 *   Outputs (right edge): "REDST_OUT", "OUT_0" … "OUT_3"
 *
 * {@code bitWidth} is always 1 now but included for future multi-bit support.
 */
public class Wire {

    public final String fromId;  // source component/node ID
    public final int    fromPort; // output port index on the source
    public final String toId;    // target component/node ID
    public final int    toPort;  // input port index on the target
    public final int    bitWidth; // reserved for future multi-bit wires (always 1)

    public Wire(String fromId, int fromPort, String toId, int toPort) {
        this(fromId, fromPort, toId, toPort, 1);
    }

    public Wire(String fromId, int fromPort, String toId, int toPort, int bitWidth) {
        this.fromId   = fromId;
        this.fromPort = fromPort;
        this.toId     = toId;
        this.toPort   = toPort;
        this.bitWidth = bitWidth;
    }

    // -----------------------------------------------------------------------
    // NBT
    // -----------------------------------------------------------------------

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582("from",     fromId);
        nbt.method_10569("fromPort",    fromPort);
        nbt.method_10582("to",       toId);
        nbt.method_10569("toPort",      toPort);
        nbt.method_10569("bitWidth",    bitWidth);
        return nbt;
    }

    public static Wire fromNbt(class_2487 nbt) {
        return new Wire(
            nbt.method_10558("from"),
            nbt.method_10550("fromPort"),
            nbt.method_10558("to"),
            nbt.method_10550("toPort"),
            nbt.method_10545("bitWidth") ? nbt.method_10550("bitWidth") : 1
        );
    }
}
