package com.gl.logicraft.block;

import com.gl.logicraft.GLLogiCraft;
import com.gl.logicraft.blockentity.LogicChipBlockEntity;
import com.gl.logicraft.registry.ModBlockEntities;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2960;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.Map;

/**
 * LogicChipBlock — a nearly-invisible attachment block.
 *
 * Placement rules:
 *  - Can be placed on any face of any block.
 *  - FACING = the direction from the chip toward its host block.
 *    (e.g., placed on top of a block → FACING = DOWN, host is below.)
 *  - Has a 0.125-thick hitbox that hugs the face it's attached to.
 *
 * Redstone:
 *  - Reads host block's incoming redstone → CircuitState.inputs[0].
 *  - Emits getWeakRedstonePower from CircuitState.outputs[0].
 *
 * Interaction:
 *  - Right-click with an item tagged `gllogicraft:wrench` → opens GUI (TODO).
 */
public class LogicChipBlock extends class_2237 {

    @Override
    protected com.mojang.serialization.MapCodec<? extends class_2237> method_53969() {
        return method_54094(LogicChipBlock::new);
    }

    // -----------------------------------------------------------------------
    // Block state property
    // -----------------------------------------------------------------------

    /** Direction pointing FROM the chip TOWARD its host block. */
    public static final class_2754<class_2350> FACING = class_2741.field_12525;

    // -----------------------------------------------------------------------
    // Hitbox shapes (0.125 thick, full on the other two axes)
    // -----------------------------------------------------------------------

    private static final Map<class_2350, class_265> SHAPES = new EnumMap<>(class_2350.class);

    static {
        double t = 0.125;
        SHAPES.put(class_2350.field_11033,  class_259.method_1081(0, 0,     0, 1, t,     1));
        SHAPES.put(class_2350.field_11036,    class_259.method_1081(0, 1 - t, 0, 1, 1,     1));
        SHAPES.put(class_2350.field_11043, class_259.method_1081(0, 0,     1 - t, 1, 1, 1));
        SHAPES.put(class_2350.field_11035, class_259.method_1081(0, 0,     0,     1, 1, t));
        SHAPES.put(class_2350.field_11039,  class_259.method_1081(1 - t, 0, 0, 1, 1,     1));
        SHAPES.put(class_2350.field_11034,  class_259.method_1081(0,     0, 0, t, 1,     1));
    }

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    public LogicChipBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(FACING, class_2350.field_11033));
    }

    // -----------------------------------------------------------------------
    // Block state
    // -----------------------------------------------------------------------

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    /**
     * On placement, set FACING = opposite of the side the player clicked.
     * e.g., player clicks top face (side = UP) → chip placed above host → FACING = DOWN.
     */
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2350 hitFace = ctx.method_8038(); // face of the target block that was clicked
        // FACING points from chip toward host → opposite of hit face
        return method_9564().method_11657(FACING, hitFace.method_10153());
    }

    // -----------------------------------------------------------------------
    // Hitbox
    // -----------------------------------------------------------------------

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPES.get(state.method_11654(FACING));
    }

    // -----------------------------------------------------------------------
    // Render type — invisible
    // -----------------------------------------------------------------------

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }

    // -----------------------------------------------------------------------
    // Block entity
    // -----------------------------------------------------------------------

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new LogicChipBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 world, class_2680 state, class_2591<T> type) {
        // No tick needed; all logic is event-driven
        return null;
    }

    // -----------------------------------------------------------------------
    // Redstone output
    // -----------------------------------------------------------------------

    @Override
    public boolean method_9506(class_2680 state) {
        return true;
    }

    @Override
    public int method_9524(
            class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        if (world.method_8321(pos) instanceof LogicChipBlockEntity be) {
            return be.getCircuitState().writeRedstone();
        }
        return 0;
    }

    // -----------------------------------------------------------------------
    // Neighbour update — read host block's redstone
    // -----------------------------------------------------------------------

    @Override
    protected void method_9612(
            class_2680 state, class_1937 world, class_2338 pos,
            class_2248 sourceBlock, @Nullable net.minecraft.class_9904 orientation, boolean notify) {

        if (world.method_8608()) return;

        if (world.method_8321(pos) instanceof LogicChipBlockEntity be) {
            // The host block sits in the FACING direction from this chip
            class_2338 hostPos = pos.method_10093(state.method_11654(FACING));
            be.getCircuitState().readRedstone(world, hostPos);
            be.evaluate();
        }
    }

    // -----------------------------------------------------------------------
    // Right-click (wrench) — GUI placeholder
    // -----------------------------------------------------------------------

    @Override
    public class_1269 method_55766(
            class_2680 state, class_1937 world, class_2338 pos,
            class_1657 player, class_3965 hit) {

        class_1799 held = player.method_6047();
        class_6862<class_1792> wrenchTag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(GLLogiCraft.MOD_ID, "wrench"));
        if (held.method_31573(wrenchTag)) {
            if (!world.method_8608()) {
                // TODO: Open the logic programming GUI
                player.method_7353(
                        net.minecraft.class_2561.method_43470("[GL_LogiCraft] GUI not yet implemented."), true);
            }
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }
}
